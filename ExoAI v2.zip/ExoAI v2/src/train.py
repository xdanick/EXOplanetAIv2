import os
import numpy as np
import pandas as pd
from scipy.signal import savgol_filter
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from tqdm import tqdm

from src.model import ExoCNN

INPUT_LEN = 200
BATCH_SIZE = 32
EPOCHS = 10
LR = 1e-3
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
DATA_META_CSV = "data/metadata.csv"
MODEL_SAVE = "model_cnn.pth"
USE_RAW_MODE = True

def load_lightcurve_csv(path):
    df = pd.read_csv(path)
    time = df.iloc[:, 0].to_numpy()
    flux = df.iloc[:, 1].to_numpy()
    mask = np.isfinite(time) & np.isfinite(flux)
    return time[mask], flux[mask]

def detrend_flux(time, flux, window=101, polyorder=3):
    if len(flux) < window:
        return flux - np.median(flux)
    trend = savgol_filter(flux, window_length=window, polyorder=polyorder, mode='mirror')
    return flux - trend

def phase_fold_and_resample(time, flux, period, out_len=INPUT_LEN):
    if period <= 0 or np.isnan(period):
        xp = np.linspace(time.min(), time.max(), out_len)
        return np.interp(xp, time, flux)
    t0 = time.min()
    phase = ((time - t0) % period) / period
    order = np.argsort(phase)
    phase_sorted = phase[order]
    flux_sorted = flux[order]
    xp = np.linspace(0, 1, out_len)
    phase_ext = np.concatenate([phase_sorted - 1.0, phase_sorted, phase_sorted + 1.0])
    flux_ext = np.concatenate([flux_sorted, flux_sorted, flux_sorted])
    res = np.interp(xp, phase_ext, flux_ext)
    return res

def preprocess_lightcurve(path, period):
    t, f = load_lightcurve_csv(path)
    if USE_RAW_MODE:
        f = (f - np.mean(f)) / (np.std(f) + 1e-9)
        if len(f) > INPUT_LEN:
            f = f[:INPUT_LEN]
        else:
            f = np.pad(f, (0, max(0, INPUT_LEN - len(f))), 'constant')
        return f.astype(np.float32)
    else:
        f = detrend_flux(t, f, window=101, polyorder=3)
        f = (f - np.mean(f)) / (np.std(f) + 1e-9)
        seq = phase_fold_and_resample(t, f, period, out_len=INPUT_LEN)
        seq = (seq - seq.mean()) / (seq.std() + 1e-9)
        return seq.astype(np.float32)

class LightcurveDataset(Dataset):
    def __init__(self, meta_df, cache_dir="cache_np", transform=None):
        self.meta = meta_df.reset_index(drop=True)
        self.transform = transform
        self.cache_dir = cache_dir
        os.makedirs(cache_dir, exist_ok=True)

    def __len__(self):
        return len(self.meta)

    def __getitem__(self, idx):
        row = self.meta.iloc[idx]
        cache_file = os.path.join(self.cache_dir, f"{row['id']}.npy")
        if os.path.exists(cache_file):
            seq = np.load(cache_file)
        else:
            seq = preprocess_lightcurve(row['filepath'], float(row['period']))
            np.save(cache_file, seq)
        if self.transform:
            seq = self.transform(seq)
        return torch.from_numpy(seq).unsqueeze(0), int(row['label_enc'])

def train_epoch(model, loader, criterion, optimizer):
    model.train()
    running_loss, correct, total = 0.0, 0, 0
    for x, y in tqdm(loader, desc="train", leave=False):
        x, y = x.to(DEVICE), y.to(DEVICE)
        optimizer.zero_grad()
        out = model(x)
        loss = criterion(out, y)
        loss.backward()
        optimizer.step()
        running_loss += loss.item() * x.size(0)
        preds = out.argmax(dim=1)
        correct += (preds == y).sum().item()
        total += x.size(0)
    return running_loss / total, correct / total

def eval_epoch(model, loader, criterion):
    model.eval()
    running_loss, correct, total = 0.0, 0, 0
    with torch.no_grad():
        for x, y in loader:
            x, y = x.to(DEVICE), y.to(DEVICE)
            out = model(x)
            loss = criterion(out, y)
            running_loss += loss.item() * x.size(0)
            preds = out.argmax(dim=1)
            correct += (preds == y).sum().item()
            total += x.size(0)
    return running_loss / total, correct / total

def main():
    meta = pd.read_csv(DATA_META_CSV)
    le = LabelEncoder()
    meta['label_enc'] = le.fit_transform(meta['label'].astype(str))

    if len(meta) > 4:
        train_df, val_test_df = train_test_split(meta, test_size=0.2, random_state=42)
        if len(val_test_df) > 1:
            val_df, test_df = train_test_split(val_test_df, test_size=0.5, random_state=42)
        else:
            val_df, test_df = val_test_df, val_test_df
    else:
        train_df, val_df, test_df = meta, meta, meta

    train_ds = LightcurveDataset(train_df)
    val_ds = LightcurveDataset(val_df)
    test_ds = LightcurveDataset(test_df)

    train_loader = DataLoader(train_ds, batch_size=BATCH_SIZE, shuffle=True, num_workers=0)
    val_loader = DataLoader(val_ds, batch_size=BATCH_SIZE, shuffle=False, num_workers=0)
    test_loader = DataLoader(test_ds, batch_size=BATCH_SIZE, shuffle=False, num_workers=0)

    model = ExoCNN(input_size=INPUT_LEN, num_classes=len(le.classes_)).to(DEVICE)
    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=LR)

    best_val_acc = 0.0
    for epoch in range(1, EPOCHS + 1):
        print(f"\nEpoch {epoch}/{EPOCHS}")
        train_loss, train_acc = train_epoch(model, train_loader, criterion, optimizer)
        val_loss, val_acc = eval_epoch(model, val_loader, criterion)
        print(f" train_loss={train_loss:.4f} train_acc={train_acc:.4f}")
        print(f"  val_loss={val_loss:.4f}  val_acc={val_acc:.4f}")

        torch.save({
            'model_state_dict': model.state_dict(),
            'label_classes': le.classes_
        }, MODEL_SAVE)
        print("  Saved checkpoint")

    chk = torch.load(MODEL_SAVE, map_location=DEVICE)
    model.load_state_dict(chk['model_state_dict'])
    test_loss, test_acc = eval_epoch(model, test_loader, criterion)
    print(f"\nTEST: loss={test_loss:.4f} acc={test_acc:.4f}")

if __name__ == "__main__":
    main()


