import torch
import torch.nn.functional as F
import numpy as np
from src.model import ExoCNN

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
MODEL_PATH = "model_cnn.pth"

def predict(flux_array):
    chk = torch.load(MODEL_PATH, map_location=DEVICE)
    label_classes = ['confirmed', 'candidate', 'false']

    model = ExoCNN(input_size=len(flux_array), num_classes=len(label_classes)).to(DEVICE)
    model_state = model.state_dict()
    loaded_state = chk['model_state_dict']

    # Загружаем только совпадающие по форме слои
    compatible_state = {k: v for k, v in loaded_state.items()
                        if k in model_state and v.shape == model_state[k].shape}
    model_state.update(compatible_state)
    model.load_state_dict(model_state, strict=False)

    model.eval()
    x = torch.tensor(flux_array, dtype=torch.float32).unsqueeze(0).unsqueeze(0).to(DEVICE)

    with torch.no_grad():
        logits = model(x)
        probs = F.softmax(logits, dim=1).cpu().numpy()[0]

    return probs

if __name__ == "__main__":
    fake_flux = np.random.randn(200).astype(np.float32)
    probs = predict(fake_flux)
    print("Predicted probabilities:")
    for cls, p in zip(['confirmed', 'candidate', 'false'], probs):
        print(f"  {cls}: {p:.3f}")
    print("Predicted class:", ['confirmed', 'candidate', 'false'][np.argmax(probs)])

